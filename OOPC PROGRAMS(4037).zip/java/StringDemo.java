public class StringDemo{
public static void main(String[] args){
String s1="Chythu";
String s2= new String(s1);
String s3= new String("chythu");
String s4=s1;
String s5="Chythu";
String s6=" ";
System.out.println(s1);
System.out.println(s2);
System.out.println(s3);
System.out.println("The length of s1 is:" + s1.length());
if (s4==s1) // equality of values
  System.out.println("True");
else
  System.out.println("False");
if (s2==s1)
  System.out.println("True");
else
  System.out.println("False");
if (s1.equals(s2)) //equality of objects
  System.out.println("True");
else
  System.out.println("False");
if (s1.equalsIgnoreCase(s5))
  System.out.println("True");
else
  System.out.println("False");
System.out.println(s1.isEmpty());
System.out.println(s6.isEmpty());
System.out.println("The character at 3rd index is :" +s1.charAt(3));
System.out.println(" Is the character b is in s1 :" +s1.indexOf('b'));
System.out.println("Is the character h is in s1 :" +s1.indexOf('h'));
System.out.println(" Is the character h in s1 :" +s1.lastIndexOf('h'));
System.out.println("Is the string tha in s1:" +s1.lastIndexOf("tha"));
System.out.println(s1.compareTo(s5));
String s7="SR Univeristy is the best university in telangana";
String arr[]=s7.split("\\s");
System.out.println("The num of char in s7 are:"+s7.length());
System.out.println("The size of arr is :"+arr.length);
for(String c:arr){
System.out.println(c);
}
String arr1[]=s1.split("y");
for(String c1:arr){
System.out.println(c1);
}
System.out.println(s1.toLowerCase());
System.out.println(s1.toUpperCase());
String s8="Ravi Chaitanya";
System.out.println(s8.trim()+s1);
System.out.println(s7.substring(3,14));
System.out.println(s7.substring(6));
}
}









