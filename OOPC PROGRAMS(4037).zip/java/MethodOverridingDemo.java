class A
{
int a,b;
A(int a,int b)
{
this.a=a;
this.b=b;
}
void show()
{
System.out.println("a and b are: "+a+","+b);
}
}
class B extends A{
int c;
B(int a,int b,int c)
{
super(a,b);
this.c=c;
}
void show()
{
System.out.println("c: "+c);
}
}
public class MethodOverridingDemo
{
public static void main(String[] args)
{
B b1=new B(10,20,30);
b1.show();
}
}