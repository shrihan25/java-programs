import java.util.*;
public class ScannerDemo
{
public static void main(String[] args)
{
Scanner in=new Scanner(System.in);
int a,b,c;
System.out.println("enter a num");
a=in.nextInt();
System.out.println("enter another num");
b=in.nextInt();
c=a/b;
System.out.println(c);
}
}
