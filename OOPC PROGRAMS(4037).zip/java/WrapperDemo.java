class WrapperDemo{
public static void main(String[] args){
 Integer i=10;
 int i1=i;
System.out.println(i+"\t"+i1);
System.out.println("the hexadecimal of 16 is :" +Integer.toHexString(16));
System.out.println("the octal value of 16 is :" +Integer.toOctalString(16));
System.out.println("the binary value of 16 is :" +Integer.toBinaryString(16));
}
}
