public class Display{
public static void main(String[] args){
int n=5;
if(n==1)
System.out.println("Hello");
else if (n==2)
System.out.println("How are you");
else if(n==3)
System.out.println("Welcome to java lab");
else
System.out.println("error msg");
}
}
