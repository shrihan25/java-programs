import java.util.*;
public class ExceptionHandling4
{
public static void main(String[] args)
{
int a,b,c=0;
try
{
a=Integer.parseInt(args[0]);
b=Integer.parseInt(args[1]);
c=a/b;
}
catch(Exception e)
{
e.printStackTrace();
System.out.println(e);
a=20;
b=10;
c=a/b;
} 
System.out.println("division is:"+c);
}
}