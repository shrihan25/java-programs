public class Greatest{
public static void main(String[] args){
int a,b,c;
a=10;
b=20;
c=3;
if (a>b && a>c)
System.out.println("a is bigger");
else if(b>c)
System.out.println("b is bigger");
else
System.out.println("c is bigger");
}
}