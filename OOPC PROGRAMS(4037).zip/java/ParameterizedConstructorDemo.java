class Add{
int a,b,c;
Add(int n1,int n2){
a=n1;
b=n2;
}
void add(){
c=a+b;
}
void display(){
System.out.println("the addition is:"+c);
}
}
public class ParameterizedConstructorDemo{
public static void main(String[] args){
Add a1=new Add(30,50);
a1.add();
a1.display();
}
}