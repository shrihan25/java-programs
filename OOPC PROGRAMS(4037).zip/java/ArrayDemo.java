public class ArrayDemo
{
public static void main(String[] args)
{
int[] a=new int[]{1,2,3,4,5};
for(int i=0;i<a.length;i++)
   System.out.println(a[i]+" ");
int[] b=new int[10];
for(int i=0;i<b.length;i++)
     b[i]=i+11;
for(int i=0;i<b.length;i++)
   System.out.println(b[i]+" ");
}
}
