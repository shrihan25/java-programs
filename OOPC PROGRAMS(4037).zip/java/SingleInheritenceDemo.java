class Vehicle{
int now,seats,mileage,speed,hp;
    public void display()
    {
    System.out.println("no of wheels:"+now);
    System.out.println("no of seats:"+seats);
    System.out.println("Mileage:"+mileage);
    System.out.println("Max Speed:"+speed);
    System.out.println("Horse power:"+hp);
    }
}
class Bike extends Vehicle{
Bike(int now,int seats,int mileage,int speed,int hp){
this.now=now;
this.seats=seats;
this.mileage=mileage;
this.speed=speed;
this.hp=hp;
}
}
public class SingleInheritenceDemo{
public static void main(String[] args){
Bike b1=new Bike(2,2,45,120,120);
b1.display();
}
}


