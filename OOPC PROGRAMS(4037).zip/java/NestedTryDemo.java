import java.util.*;
public class NestedTryDemo
{
public static void main(String[] args)
{
int a,b,c=0;
try
{
a=Integer.parseInt(args[0]);
b=Integer.parseInt(args[1]);
try
{
c=a/b;
}
catch(ArithmeticException ex)
{
System.out.println(ex);
} 
}
catch(ArrayIndexOutOfBoundsException e)
{
System.out.println(e);
}
System.out.println("division is:"+c);
}
}