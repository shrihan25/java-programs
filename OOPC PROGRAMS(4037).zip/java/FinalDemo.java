class Add
{
final int a;
Add()
{
a=10;
}
void add()
{
//a=a+1; this is an error as we are assigning a value to final variable
System.out.println(a);
}
}
public class FinalDemo
{
public static void main(String[] args)
{
Add a=new Add();
a.add();
}
}

