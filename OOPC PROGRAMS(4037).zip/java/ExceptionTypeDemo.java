public class ExceptionTypeDemo
{
public static void main(String[] args)
{
String s="abc";
int i=Integer.parseInt(s);
String s1=null;
System.out.println(s1.length());
}
}