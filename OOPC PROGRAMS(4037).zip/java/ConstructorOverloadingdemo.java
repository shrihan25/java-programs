class Student{
String htno,name,addr,phno,email;
Student(String name,String addr,String phno){
this.htno="4017";
this.name=name;
this.addr=addr;
this.phno=phno;
this.email="abc@m";
}
Student(String htno,String name,String addr,String phno,String email){
this(name,addr,phno);
this.htno=htno;
this.email=email;
}
void show(){
System.out.println("htno:"+ htno);
System.out.println("name:"+ name);
System.out.println("addr:"+ addr);
System.out.println("phno:"+ phno);
System.out.println("email id:"+ email);
}
}
public class ConstructorOverloadingdemo{
public static void main(String[] args){
Student s1=new Student("kaveri","wgl","7xxxxxx");
s1.show();
Student s2=new Student("4040","varshi","hyd","9xxxxx","varshi@s");
s2.show();
}
}
