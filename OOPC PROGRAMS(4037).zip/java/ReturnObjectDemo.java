class Number{
int num;
Number compare(Number n){
if(this.num<n.num)
  return this;
else
  return n;
}
}
public class ReturnObjectDemo{
public static void main(String[] args){
Number n1=new Number();
Number n2=new Number();
n1.num=20;
n2.num=30;
Number n3=n2.compare(n1);
System.out.println("n3.num "+ n3.num +" is small");
}
}
