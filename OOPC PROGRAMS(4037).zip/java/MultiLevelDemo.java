class A{
void a(){
System.out.println("im in class A");
}
}
class B extends A{
    void b(){
    System.out.println("im in class B");
    }
}
class C extends B{
void c(){
System.out.println("im in class C");
}
}
public class MultiLevelDemo{
public static void main(String[] args){
C c1=new C();
    c1.c();
    c1.b();
    c1.a();
}
}