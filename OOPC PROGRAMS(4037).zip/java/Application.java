import java.util.*
public class Application
{
	public static void main(String[] args) {
	        String Username,Password,college_mail,htno;
	        college_mail="2103A54017@sru.edu.in";
	        htno="2103A54017";
	        System.out.println("enter username:");
	        Scanner s1 =new Scanner(System.in);
	        Username=s1.nextLine();
	        System.out.println("enter password:");
	        Password=s1.nextLine();
	        String cm=college_mail.toLowerCase();
	        String ht=htno.toUpperCase();
	        if ((cm.equals(Username)) &&  (ht.equals(Password)))
	           System.out.println("valid");
	       else
	           System.out.println(" not valid");
	}
}