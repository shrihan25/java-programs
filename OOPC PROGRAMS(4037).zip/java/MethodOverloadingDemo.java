class Add{
void add(){
System.out.println(10+20);
}
void add(int a){
System.out.println(a+a);
}
void add(double a){
System.out.println(a+a);
}
void add(int a,double b){
System.out.println(a+b);
}
int add(int a,int b){
return (a+b);
}
}
public class MethodOverloadingDemo{
public static void main(String[] args){
Add a1=new Add();
a1.add();
a1.add(10);
a1.add(20.34);
a1.add(10,20.67);
System.out.println(a1.add(10,20));
}
}
