class Add{
int a,b,c;
    void init(){
    a=20;
    b=30;
    }
    void Add(){
    c=a+b;
    }
    void display(){
    System.out.println("The addition is:"+c);
    }
}
public class ObjectDemo{
public static void main(String[] args){
    Add a1=new Add();
    a1.init();
    a1.Add();
    a1.display();
}
}