class Add{
int a,b,c;
Add(){
a=20;
b=30;
}
void add(){
c=a+b;
}
void display(){
System.out.println("the addition is:"+c);
}
}
public class ConstructorDemo{
public static void main(String[] args){
Add a1=new Add();
a1.add();
a1.display();
}
}