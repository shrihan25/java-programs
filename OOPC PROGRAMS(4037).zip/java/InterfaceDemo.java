interface Number
{
int a=10,b=20;
void add(int a,int b);
void sub(int a,int b);
void mul(int a,int b);
void div(int a,int b);
}
class NumImp implements Number
{
public void add(int a,int b)
{
System.out.println(a+b);
}
public void sub(int a,int b)
{
System.out.println(a-b);
}
public void mul(int a,int b)
{
System.out.println(a*b);
}
public void div(int a,int b)
{
System.out.println(a/b);
}
}
public class InterfaceDemo
{
public static void main(String[] args)
{
NumImp n=new NumImp();
n.add(10,20);
n.sub(10,20);
n.mul(10,20);
n.div(10,20);
}
}

