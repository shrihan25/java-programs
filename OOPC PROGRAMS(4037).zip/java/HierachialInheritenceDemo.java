class Vehicle1{
int now,seats,mileage,speed,hp;
    public void display()
    {
    System.out.println("no of wheels:"+now);
    System.out.println("no of seats:"+seats);
    System.out.println("Mileage:"+mileage);
    System.out.println("Max Speed:"+speed);
    System.out.println("Horse power:"+hp);
    }
}
class Bike1 extends Vehicle1{
Bike1(int now,int seats,int mileage,int speed,int hp){
this.now=now;
this.seats=seats;
this.mileage=mileage;
this.speed=speed;
this.hp=hp;
}
}
class Car extends Vehicle1{
Car(int now,int seats,int mileage,int speed,int hp){
this.now=now;
this.seats=seats;
this.mileage=mileage;
this.speed=speed;
this.hp=hp;
}
}
public class HierachialInheritenceDemo{
public static void main(String[] args){
Bike1 b1=new Bike1(2,2,45,120,120);
Car c1=new Car(4,5,60,140,140);
b1.display();
c1.display();
}
}