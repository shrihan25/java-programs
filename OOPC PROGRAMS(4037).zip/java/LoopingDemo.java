class LoopingDemo{
public static void main(String[] args){
int a[]={21,25,53,74,55};
for(int i:a){
System.out.println(i);
}
}
}