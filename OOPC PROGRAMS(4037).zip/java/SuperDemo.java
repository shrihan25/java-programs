class Employee
{
int eid;
private String name;
private int age;
Employee()
{
eid=1010;
name="kaveri";
age=20;
}
void show()
{
System.out.println(eid+" "+name);
}
}
class Tstaff extends Employee
{
int noh;
String sub_name;
Tstaff()
{
super();
noh=10;
sub_name="OOPC";
}
void display()
{
super.show();
System.out.println(noh+","+sub_name);
}
}
public class SuperDemo
{
public static void main(String[] args){
Tstaff t1=new Tstaff();
t1.display();
}
}