public class Palindrome{
public static void main(String[] args){
int n=34,r=0,s=0,m;
m=n;
while(n>0)
{
r=n%10;
s=s*10+r;
n=n/10;
}
if(s==m)
System.out.println("it is a palindrome");
else
System.out.println("not a palindrome");
}
}
 
