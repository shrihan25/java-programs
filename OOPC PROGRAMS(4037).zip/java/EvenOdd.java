public class EvenOdd{
public static void main(String[] args){
int n=23;
if (n%2==0)
System.out.println("even number");
else
System.out.println("odd number");
}
}