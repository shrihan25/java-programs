public class TwoArrayDemo
{
public static void main(String[] args)
{
int t[][]=new int[][]{{1,2,3},{4,5,6},{7,8,9}};
for(int i=0;i<3;i++)
{
   for(int j=0;j<3;j++)
     {
        System.out.println(t[i][j]+" ");
}
System.out.println();
}
System.out.println("Juggle Array");
int t1[][]=new int[][]{{1,2},{4,5,6,7},{8},{9,10,11,12,13}};
for(int i=0;i<t1.length;i++)
{
for(int j=0;j<t1[i].length;j++)
{
System.out.println(t1[i][j]+" ");
}
System.out.println();
}
}
}
    