class Add
{
static int a;
int b;
void operation()
{
System.out.println("static value:"+ ++a+"normal value:"+ ++b);
}
static void smethod()
{
System.out.println(a);
}
}
public class StaticDemo
{
public static void main(String[] args)
{
Add a1=new Add();
a1.operation();
Add a2=new Add();
a2.operation();
Add a3=new Add();
a3.operation();
Add.smethod();
}
}

