import java.util.*;
public class ExceptionHandlingDemo
{
public static void main(String[] args)
{
int a,b,c=0;
Scanner in=new Scanner(System.in);
System.out.println("enter a num");
a=in.nextInt();
System.out.println("enter b num");
b=in.nextInt();
try
{
c=a/b;
}
catch(ArithmeticException ae)
{
System.out.println("denominator should not be zero");
System.out.println("enter b value again");
b=in.nextInt();
c=a/b;
}
System.out.println("division is:"+c);
}
}