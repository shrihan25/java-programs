class A
{
int a;
A()
{
a=10;
}
final void show()
{
System.out.println("a="+a);
}
}
class B extends A
{
int b;
B()
{
a=20;
b=30;
}
//void show()-->error generated due to declaration of show() in a as final
void showB()
{
System.out.println("a and b are"+a+" ,"+b);
}
}
public class FinalMethodDemo
{
public static void main(String[] args)
{
B obj=new B();
obj.showB();
}
}