final class A
{
int a;
void show()
{
System.out.println("a="+a);
}
}
class B extends A //error-->class a cannot be inherited to b
{
int b;
void show()
{
System.out.println("a and b are"+a+" ,"+b);
}
}
public class FinalClassDemo
{
public static void main(String[] args)
{
B obj=new B();
obj.show();
}
}