import java.util.*;
public class ExceptionHandling3
{
public static void main(String[] args)
{
int a,b,c=0;
try
{
a=Integer.parseInt(args[0]);
b=Integer.parseInt(args[1]);
c=a/b;
}
catch(ArrayIndexOutOfBoundsException | ArithmeticException e)
{
e.printStackTrace();
a=20;
b=10;
c=a/b;
} 
System.out.println("division is:"+c);
}
}