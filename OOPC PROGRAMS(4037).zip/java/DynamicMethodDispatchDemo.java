class A
{
int a,b;
A(int a,int b)
{
this.a=a;
this.b=b;
}
void show()
{
System.out.println("a ="+a);
System.out.println("b ="+b);

}
}
class B extends A{
int c;
B(int a,int b,int c)
{
super(a,b);
this.c=c;
}
void show()
{
System.out.println("a: "+a);
System.out.println("b: "+b);
System.out.println("c: "+c);
}
}
public class DynamicMethodDispatchDemo
{
public static void main(String[] args)
{
A subobj;
subobj =new A(10,20);
subobj.show();
subobj=new B(10,20,30);
subobj.show();
}
}