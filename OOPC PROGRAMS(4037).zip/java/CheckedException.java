public class CheckedException
{
public static void main(String[] args) throws InterruptedException
{
System.out.println("hi");
Thread.sleep(3000);
System.out.println("bye");
}
}