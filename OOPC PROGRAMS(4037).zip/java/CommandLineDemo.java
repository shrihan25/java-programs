class Student
{
String name,addr;
int age;
Student(String n,int a,String add)
{
name=n;
age=a;
addr=add;
}
void disp()
{
System.out.println("name:"+name);
System.out.println("age:"+age);
System.out.println("address:"+addr);
}
}
public class CommandLineDemo
{
public static void main(String[] args)
{
String n=args[0];
int a=Integer.parseInt(args[1]);
String addr=args[2];
Student s1=new Student(n,a,addr);
s1.disp();
}
}