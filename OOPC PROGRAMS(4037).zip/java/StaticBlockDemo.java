class Number
{
static int a=10;
static int b;
static void disp()
{
System.out.println(a+" "+b);
}
}
public class StaticBlockDemo
{
public static void main(String[] args)
{
Number.b=20;
Number.disp();
}
static
{
System.out.println("I am in static block");
}
}