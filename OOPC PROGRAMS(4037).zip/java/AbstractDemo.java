abstract class Shape{
int l,b,h;
Shape()
{
l=b=h=-1;
}
abstract void CalVol();
}
class Box extends Shape{
Box(int l,int b,int h)
{
this.l=l;
this.b=b;
this.h=h;
}
void CalVol()
{
System.out.println("the volume of box is :"+l*b*h);
}
}
public class AbstractDemo
{
public static void main(String[] args)
{
Box b=new Box(10,20,30);
b.CalVol();
}
}